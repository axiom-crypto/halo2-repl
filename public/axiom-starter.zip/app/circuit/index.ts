import { Halo2Lib, Halo2Data } from "@axiom-crypto/halo2-js";
import { CircuitInputs } from "./constants";

export const circuit = async (
  halo2Lib: Halo2Lib,
  halo2Data: Halo2Data,
  { txHash, block, punkAddr, myAddr, tokenId1, tokenId2 }: CircuitInputs
) => {
  const { witness, constant, add, or, log, addToCallback } = halo2Lib;
  const {} = halo2Data;
  log(add(constant(5), constant(19)));

  for (let i = 0; i < 100; i++) {
    add(witness(100000), witness(0));
  }
};
